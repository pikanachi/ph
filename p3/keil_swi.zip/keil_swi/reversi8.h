#ifndef __REVERSI8__H
#define __REVERSI8__H

void reversi8(void);

#endif
