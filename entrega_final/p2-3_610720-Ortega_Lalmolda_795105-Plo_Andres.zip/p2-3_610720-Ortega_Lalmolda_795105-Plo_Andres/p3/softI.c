#include "softI.h"

uint32_t __SWI_0 (void){
	return temporizador_leer();
}
