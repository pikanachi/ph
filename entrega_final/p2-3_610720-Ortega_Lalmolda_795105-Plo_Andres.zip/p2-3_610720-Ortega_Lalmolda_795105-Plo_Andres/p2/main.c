#include "planificador.h"

int main (void) {
	planificador_main();
	return 0;
}
