#ifndef PLANIFICADOR_H
#define PLANIFICADOR_H

#include "cola.h"
#include "gestor_alarmas.h"
#include "gestor_IO.h"
#include "gestor_pulsacion.h"
#include "gestor_energia.h"

void planificador_main(void);

#endif
